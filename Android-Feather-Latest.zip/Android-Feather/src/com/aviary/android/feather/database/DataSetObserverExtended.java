package com.aviary.android.feather.database;

import android.database.DataSetObserver;

public abstract class DataSetObserverExtended extends DataSetObserver {

	public void onAdded() {
		// Do Nothing
	}

	public void onRemoved() {
		// Do Nothing
	}
}
